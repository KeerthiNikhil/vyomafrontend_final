import { useState, useEffect } from "react";
import axios from "axios";
import { Input } from "../components/ui/input";
import { Textarea } from "../components/ui/textarea";
import { Button } from "../components/ui/button";
import { toast } from "sonner";

const AddProduct = () => {

  const token = localStorage.getItem("token");

  const [uploadType,setUploadType] = useState("single");

  const [shops,setShops] = useState<any[]>([]);
  const [shopId,setShopId] = useState("");

  const [name,setName] = useState("");
  const [category,setCategory] = useState("");
  const [price,setPrice] = useState("");
  const [stock,setStock] = useState("");
  const [description,setDescription] = useState("");

  const [discountType,setDiscountType] = useState("");
  const [discountValue,setDiscountValue] = useState("");

  const [units,setUnits] = useState("");

  const [images,setImages] = useState<File[]>([]);

  const [file,setFile] = useState<any>(null);

  const [expiryDate,setExpiryDate] = useState("");
  const [weight,setWeight] = useState("");
  const [size,setSize] = useState("");
  const [brand,setBrand] = useState("");
  const [modelNumber,setModelNumber] = useState("");
  const [author,setAuthor] = useState("");
  const [ageGroup,setAgeGroup] = useState("");
  const [material,setMaterial] = useState("");

  /* ================= GET SHOPS ================= */

  useEffect(()=>{

    const fetchShops = async()=>{

      try{

        const res = await axios.get(
          "http://localhost:8000/api/v1/shops/my-shops",
          {headers:{Authorization:`Bearer ${token}`}}
        );

        setShops(res.data.data);

      }catch{

        toast.error("Failed to load shops");

      }

    };

    fetchShops();

  },[]);


  /* ================= HANDLE IMAGE ================= */

  const handleImages = (e:any)=>{

  const files = Array.from(e.target.files);

  const newImages = [...images, ...files];

  if(newImages.length > 4){

    toast.error("Maximum 4 images allowed");
    return;

  }

  setImages(newImages);

};

  /* ================= SINGLE PRODUCT ================= */

  const handleSubmit = async()=>{

    if(!shopId || !name || !category || !price || !stock){

      toast.error("Fill required fields");
      return;

    }

    try{

      const formData = new FormData();

      formData.append("shop",shopId);
      formData.append("name",name);
      formData.append("category",category);
      formData.append("price",price);
      formData.append("stock",stock);
      formData.append("description",description);
      formData.append("discountType",discountType);
      formData.append("discountValue",discountValue);
      formData.append("units",units);

      images.forEach((img)=>{
        formData.append("images",img);
      });

      formData.append("expiryDate",expiryDate);
      formData.append("weight",weight);
      formData.append("size",size);
      formData.append("brand",brand);
      formData.append("modelNumber",modelNumber);
      formData.append("author",author);
      formData.append("ageGroup",ageGroup);
      formData.append("material",material);

      await axios.post(
        "http://localhost:8000/api/v1/products",
        formData,
        {
          headers:{
            Authorization:`Bearer ${token}`,
            "Content-Type":"multipart/form-data"
          }
        }
      );

      toast.success("Product Added Successfully 🚀");

    }catch(error:any){

      toast.error(
        error.response?.data?.message || "Product creation failed"
      );

    }

  };


  /* ================= BULK UPLOAD ================= */

  const handleBulkUpload = async()=>{

    if(!shopId){

      toast.error("Select shop");
      return;

    }

    if(!file){

      toast.error("Select Excel file");
      return;

    }

    try{

      const formData = new FormData();

      formData.append("file",file);
      formData.append("shopId",shopId);

      await axios.post(
        "http://localhost:8000/api/v1/products/bulk-upload",
        formData,
        {
          headers:{
            Authorization:`Bearer ${token}`,
            "Content-Type":"multipart/form-data"
          }
        }
      );

      toast.success("Products uploaded successfully 🚀");

    }catch{

      toast.error("Upload failed");

    }

  };


  return(

    <div className="max-w-4xl mx-auto p-6 space-y-6">

      <h1 className="text-3xl font-bold text-gray-800">
        Add Product
      </h1>


{/* SWITCH */}

<div className="flex gap-4 mb-4">

<Button
onClick={()=>setUploadType("single")}
className={`${uploadType==="single"
? "bg-blue-600 text-white"
: "bg-gray-200"} px-6 py-2`}
>

📦 Single Product

</Button>


<Button
onClick={()=>setUploadType("bulk")}
className={`${uploadType==="bulk"
? "bg-blue-600 text-white"
: "bg-gray-200"} px-6 py-2`}
>

📊 Bulk Upload

</Button>

</div>



{/* ================= BULK UPLOAD ================= */}

{uploadType==="bulk" &&(

<div className="bg-white shadow-md rounded-xl p-8 space-y-5 border">

<h2 className="text-lg font-semibold">

Upload Excel File

</h2>


<select
value={shopId}
onChange={(e)=>setShopId(e.target.value)}
className="w-full border rounded-md px-3 py-2"
>

<option value="">Select Shop</option>

{shops.map((shop)=>(
<option key={shop._id} value={shop._id}>
{shop.shopName}
</option>
))}

</select>


<input
type="file"
accept=".xlsx,.csv"
onChange={(e:any)=>setFile(e.target.files[0])}
className="border p-2 rounded w-full"
/>


<Button
onClick={handleBulkUpload}
>

Upload Products

</Button>

</div>

)}



{/* ================= SINGLE PRODUCT ================= */}

{uploadType==="single" &&(

<div className="bg-white shadow-md rounded-xl p-8 space-y-5 border">

<select
value={shopId}
onChange={(e)=>setShopId(e.target.value)}
className="w-full border rounded-md px-3 py-2"
>

<option value="">Select Shop</option>

{shops.map((shop)=>(
<option key={shop._id} value={shop._id}>
{shop.shopName}
</option>
))}

</select>


<Input
placeholder="Product Name"
value={name}
onChange={(e)=>setName(e.target.value)}
/>


<select
value={category}
onChange={(e)=>setCategory(e.target.value)}
className="w-full border rounded-md px-3 py-2"
>

<option value="">Select Category</option>
<option value="food">Food</option>
<option value="clothing">Clothing</option>
<option value="electronics">Electronics</option>
<option value="books">Books</option>
<option value="toys">Toys</option>

</select>


<div className="grid md:grid-cols-2 gap-4">

<Input
type="number"
placeholder="Price"
value={price}
onChange={(e)=>setPrice(e.target.value)}
/>

<Input
type="number"
placeholder="Stock"
value={stock}
onChange={(e)=>setStock(e.target.value)}
/>

</div>


<Textarea
placeholder="Description"
value={description}
onChange={(e)=>setDescription(e.target.value)}
/>


<Input
placeholder="Units (example: 500g,1kg or S,M,L)"
value={units}
onChange={(e)=>setUnits(e.target.value)}
/>


<div className="grid md:grid-cols-2 gap-4">

<select
value={discountType}
onChange={(e)=>setDiscountType(e.target.value)}
className="border rounded-md px-3 py-2"
>

<option value="">Discount Type</option>
<option value="percentage">Percentage</option>
<option value="flat">Flat</option>

</select>

<Input
type="number"
placeholder="Discount Value"
value={discountValue}
onChange={(e)=>setDiscountValue(e.target.value)}
/>

</div>


<div>

<p className="text-sm font-medium text-gray-600">

Upload Product Images (Max 4)

</p>

<input
type="file"
multiple
accept="image/*"
onChange={handleImages}
className="w-full border rounded-md px-3 py-2"
/>
<div className="flex gap-3 mt-3 flex-wrap">

{images.map((img,index)=>(
<img
key={index}
src={URL.createObjectURL(img)}
className="w-16 h-16 object-cover rounded-md border"
/>
))}

</div>
</div>


<div className="flex justify-end pt-4">

<Button
onClick={handleSubmit}
className="bg-blue-700 text-white px-6 py-2"
>

Add Product

</Button>

</div>

</div>

)}

</div>

);

};

export default AddProduct;